#ifndef _UTILIDADES_H__
#define _UTILIDADES_H__

#include <iostream>

using namespace std;

void descomponer(int numero, int factores[],int &numeroFactores);
void mostrar(int factores[], int numeroFactores);
void index(int array[],int pos,int val);

#endif
