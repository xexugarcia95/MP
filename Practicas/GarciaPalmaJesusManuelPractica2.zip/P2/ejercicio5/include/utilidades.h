#ifndef _UTILIDADES_H__
#define _UTILIDADES_H__

#include <iostream>

using namespace std;

bool insertarCadena(char cadena1[],char cadena2[],int posicion,char resultado[]);

int Longitud(char cadena[]); //Devuelve el tamaño de la cadena


#endif
