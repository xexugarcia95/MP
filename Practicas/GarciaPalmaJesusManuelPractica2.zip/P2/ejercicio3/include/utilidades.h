#ifndef _UTILIDADES_H__
#define _UTILIDADES_H__

#include <iostream>

using namespace std;

void imprimirArray(int array[],int tam);
void obtenerMayorSecuenciaMonotonaCreciente(int array1[],int tam1,int array2[],int &tam2);


#endif
