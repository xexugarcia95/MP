#ifndef _UTILIDADES_H__
#define _UTILIDADES_H__

#include <iostream>
using namespace std;


int mezclar(double v1[],int tam1,double v2[],int tam2, double v3[]); //función de mezclado
void imprimirArray(double v[],int tam); //funcion de impresion de array
void ordenar(double v[],int tam); //funcion de ordenado



#endif
