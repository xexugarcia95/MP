#ifndef _UTILIDADES_H__
#define _UTILIDADES_H__

#include <iostream>

using namespace std;

int localizarSubcadena(char cadena[],char subcadena[]);



#endif
