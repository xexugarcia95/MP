#ifndef _UTILIDADES_H__
#define _UTILIDADES_H__

#include <iostream>
#include "Valor.h"

using namespace std;

int combinarSuma(Valor array1[],int tam1,Valor array2[],int tam2,Valor resultado[]);
void mostrarContenido(Valor array[],int tam);


#endif
